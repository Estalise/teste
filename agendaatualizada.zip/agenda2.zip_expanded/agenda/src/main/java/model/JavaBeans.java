
package model;

public class JavaBeans {
	private String idcon;
	private String nome;
	private String fone;
	private String email;
	private String idcpf;
	private String senha;
	private String datacriacao;
	private String idendereco;
	private String estado;
	private String bairro;

	public JavaBeans() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JavaBeans(String idcon, String nome, String fone, String email, String idcpf, String senha,
			String datacriacao, String idendereco, String estado, String bairro) {
		super();
		this.idcon = idcon;
		this.nome = nome;
		this.fone = fone;
		this.email = email;
		this.idcpf = idcpf;
		this.senha = senha;
		this.datacriacao = datacriacao;
		this.idendereco = idendereco;
		this.estado = estado;
		this.bairro = bairro;

	}

	public String getIdcon() {
		return idcon;
	}

	public void setIdcon(String idcon) {
		this.idcon = idcon;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getFone() {
		return fone;
	}

	public void setFone(String fone) {
		this.fone = fone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIdcpf() {
		return idcpf;
	}

	public void setIdcpf(String idcpf) {
		this.idcpf = idcpf;
	}

	public String getsenha() {
		return senha;
	}

	public void setsenha(String senha) {
		this.senha = senha;
	}

	public String getdatacriacao() {
		return datacriacao;
	}

	public void setdatacriacao(String datacriacao) {
		this.datacriacao = datacriacao;
	}

	public String getidendereco() {
		return idendereco;
	}

	public void setidendereco(String idendereco) {
		this.idendereco = idendereco;
	}
	public String getestado() {
		return estado;
	}

	public void setestado(String estado) {
		this.estado = estado;
	}
	public String getbairro() {
		return bairro;
	}

	public void setbairro(String bairro) {
		this.bairro = bairro;
	}

}
