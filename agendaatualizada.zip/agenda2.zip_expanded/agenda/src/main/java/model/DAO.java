
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DAO {

	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://127.0.01:3306/dbagenda?useTimezone=true&serverTimezone=UTC";
	private String user = "root";
	private String password = "Cuild123@#1806A";

	private Connection conectar() {
		Connection con = null;
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
			return con;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

	public void testeconexao() {
		try {
			Connection con = conectar();
			System.out.println(con);
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void inserirContato(JavaBeans contato) {
		String create = "insert into contatos (nome,fone,email,idcpf,senha,idendereco,estado,bairro) values (?,?,?,?,?,?,?,?)";

		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(create);

			pst.setString(1, contato.getNome());
			pst.setString(2, contato.getFone());
			pst.setString(3, contato.getEmail());
            pst.setString(4, contato.getIdcpf());
			pst.setString(5, contato.getsenha());
            pst.setString(6, contato.getidendereco());
            pst.setString(7, contato.getestado());
            pst.setString(8, contato.getbairro());

			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public ArrayList<JavaBeans> listarContatos() {
		ArrayList<JavaBeans> contatos = new ArrayList<>();

		String read = "select * from contatos order by nome";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(read);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				String idcon = rs.getString(1);
				String nome = rs.getString(2);
				String fone = rs.getString(3);
				String email = rs.getString(4);
				String idcpf = rs.getString(5);
				String senha = rs.getString(6);
				String idendereco = rs.getString(7);
				String estado = rs.getString(8);
				String bairro = rs.getString(9);
				String datacriacao = rs.getString(10);

				contatos.add(new JavaBeans(idcon, nome, fone, email, idcpf, senha,idendereco,datacriacao, estado, bairro));
			}
			con.close();
			return contatos;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

	public void selecionarContato(JavaBeans contato) {
		String read2 = "select * from contatos where idcon = ?";

		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(read2);
			pst.setString(1, contato.getIdcon());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				contato.setIdcon(rs.getString(1));
				contato.setNome(rs.getString(2));
				contato.setFone(rs.getString(3));
				contato.setEmail(rs.getString(4));
				contato.setIdcpf(rs.getString(5));
				contato.setsenha(rs.getString(6));
				contato.setidendereco(rs.getString(7));
				contato.setestado(rs.getString(8));
				contato.setbairro(rs.getString(9));
				contato.setdatacriacao(rs.getString(10));

			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// editar contato

	public void alterarContato(JavaBeans contato) {
		String create = "update contatos set nome=?,fone=?,email=?,idcpf=?,senha=?,idendereco=?,estado=?,bairro=? where idcon=?";

		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(create);
			pst.setString(1, contato.getNome());
			pst.setString(2, contato.getFone());
			pst.setString(3, contato.getEmail());
			pst.setString(4, contato.getIdcpf());
			pst.setString(5, contato.getsenha());
			pst.setString(6, contato.getidendereco());
			pst.setString(7, contato.getestado());
			pst.setString(8, contato.getbairro());
			pst.setString(9, contato.getIdcon());

			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void deletarContato(JavaBeans contato) {

		String delete = "delete from contatos where idcon=?";

		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(delete);
			pst.setString(1, contato.getIdcon());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
