/**
 * 
 */

function validar(){
	let nome = frmcontato.nome.value
	let fone = frmcontato.fone.value
	if (nome === ""){
		
	alert('Preencha o campo Nome')
	frmcontato.nome.focus()
	return false
	}else if (fone === ""){
		
	alert('Preencha o campo Fone')
	frmcontato.fone.focus()
	return false
	}else {
		document.forms["frmcontato"].submit()
	}
}